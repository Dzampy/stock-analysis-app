# Stock Analysis Tool

A comprehensive web-based stock analysis tool that provides technical indicators, financial metrics, and interactive charts for stock market analysis.

## Features

- **Real-time Stock Data**: Fetch live stock data from Yahoo Finance
- **Interactive Charts**: 
  - Price chart with multiple technical indicators
  - RSI (Relative Strength Index) chart
  - MACD (Moving Average Convergence Divergence) chart
- **Technical Indicators**:
  - Simple Moving Averages (SMA 20, SMA 50)
  - Exponential Moving Averages (EMA 12, EMA 26)
  - Bollinger Bands
  - RSI (14-period)
  - MACD with signal line and histogram
- **Financial Metrics**:
  - Market Cap, P/E Ratio, Forward P/E
  - Dividend Yield, Beta, EPS
  - Price to Book, Profit Margin
  - 52-week high/low
  - Volatility metrics
- **Company Information**: Detailed company description and sector information

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Set up SEC API key (optional, for insider trading data):
   - Register for a free API key at https://sec-api.io/
   - Copy the `.env` file (if it doesn't exist, create it):
     ```bash
     cp .env.example .env  # or create .env manually
     ```
   - Edit `.env` and add your SEC API key:
     ```
     SEC_API_KEY=your_actual_api_key_here
     ```
   - Note: If SEC API key is not set, the tool will use fallback sources (Finviz, MarketBeat, yfinance) for insider trading data

## Usage

1. Start the Flask server:
```bash
python app.py
```

2. Open your browser and navigate to:
```
http://localhost:5001
```

3. Enter a stock ticker symbol (e.g., AAPL, MSFT, TSLA, GOOGL) and click "Analyze"

## Requirements

- Python 3.7+
- Flask
- yfinance (for stock data)
- pandas, numpy (for data processing)
- ta (for technical analysis)

## Example Tickers

Try analyzing these popular stocks:
- AAPL (Apple)
- MSFT (Microsoft)
- GOOGL (Google)
- TSLA (Tesla)
- AMZN (Amazon)
- META (Meta/Facebook)

## Features (Extended)

- **Insider Trading**: Official SEC Form 3, 4, 5 filings via SEC API (with fallback to Finviz/MarketBeat)
- **Analyst Ratings**: Individual analyst recommendations and price targets
- **News & Sentiment**: Stock news from StockTitan with AI-powered sentiment analysis
- **Financials Analysis**: Comprehensive financial health analysis with company stage detection
- **Earnings Calendar**: Upcoming earnings reports
- **Price Alerts**: Set target prices with browser notifications
- **Watchlist**: Track multiple stocks
- **Dark Mode**: Toggle between light and dark themes

## Notes

- Stock data is fetched from Yahoo Finance (free, no API key required)
- Insider trading data uses SEC API (requires free API key) with automatic fallback to other sources
- Data may have slight delays (15-20 minutes) for real-time prices
- Some metrics may not be available for all stocks
- The tool uses 1 year of historical data by default

