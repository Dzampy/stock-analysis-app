from flask import Flask, render_template, jsonify, request
import yfinance as yf
import pandas as pd
import numpy as np
from ta.trend import MACD, SMAIndicator, EMAIndicator
from ta.momentum import RSIIndicator
from ta.volatility import BollingerBands
from datetime import datetime, timedelta
import json
import time
import math
import os
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import requests
from bs4 import BeautifulSoup
import feedparser
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# SEC API configuration
SEC_API_KEY = os.getenv('SEC_API_KEY')

# Initialize sentiment analyzer
sentiment_analyzer = SentimentIntensityAnalyzer()

def clean_for_json(data):
    """Replace NaN and inf values with None for JSON serialization"""
    if isinstance(data, pd.Series):
        data = data.tolist()
    if isinstance(data, (list, tuple)):
        return [clean_for_json(item) for item in data]
    elif isinstance(data, dict):
        return {key: clean_for_json(value) for key, value in data.items()}
    elif isinstance(data, (float, np.floating, np.number)):
        if pd.isna(data) or math.isnan(data) or math.isinf(data):
            return None
        return float(data)
    elif pd.isna(data):
        return None
    return data

def get_stock_data(ticker, period='1y'):
    """Fetch stock data from Yahoo Finance"""
    try:
        # Try using download method first (more reliable)
        try:
            hist = yf.download(ticker, period=period, progress=False, show_errors=False, auto_adjust=True)
            if hist.empty:
                # Fallback to Ticker method
                stock = yf.Ticker(ticker)
                hist = stock.history(period=period, auto_adjust=True)
        except:
            # Fallback to Ticker method
            stock = yf.Ticker(ticker)
            hist = stock.history(period=period, auto_adjust=True)
        
        if hist.empty:
            return None
        
        # Handle multi-level columns from download()
        if isinstance(hist.columns, pd.MultiIndex):
            hist.columns = hist.columns.droplevel(1)
        
        # Get additional info with error handling
        info = {}
        try:
            stock = yf.Ticker(ticker)
            # Add small delay to avoid rate limiting
            time.sleep(0.5)
            info = stock.info
            if not info or 'symbol' not in info:
                # Create minimal info if API fails
                info = {
                    'longName': ticker,
                    'symbol': ticker,
                    'sector': 'N/A',
                    'industry': 'N/A',
                    'longBusinessSummary': 'Data temporarily unavailable from Yahoo Finance API.'
                }
        except Exception as e:
            print(f"Warning: Could not fetch info for {ticker}: {str(e)}")
            # Create minimal info
            info = {
                'longName': ticker,
                'symbol': ticker,
                'sector': 'N/A',
                'industry': 'N/A',
                'longBusinessSummary': 'Data temporarily unavailable from Yahoo Finance API.'
            }
        
        return {
            'history': hist,
            'info': info
        }
    except Exception as e:
        print(f"Error fetching data for {ticker}: {str(e)}")
        return None

def calculate_technical_indicators(df):
    """Calculate technical indicators"""
    indicators = {}
    
    # Moving Averages
    indicators['sma_20'] = SMAIndicator(df['Close'], window=20).sma_indicator().tolist()
    indicators['sma_50'] = SMAIndicator(df['Close'], window=50).sma_indicator().tolist()
    indicators['ema_12'] = EMAIndicator(df['Close'], window=12).ema_indicator().tolist()
    indicators['ema_26'] = EMAIndicator(df['Close'], window=26).ema_indicator().tolist()
    
    # RSI
    rsi = RSIIndicator(df['Close'], window=14)
    indicators['rsi'] = rsi.rsi().tolist()
    
    # MACD
    macd = MACD(df['Close'])
    indicators['macd'] = macd.macd().tolist()
    indicators['macd_signal'] = macd.macd_signal().tolist()
    indicators['macd_diff'] = macd.macd_diff().tolist()
    
    # Bollinger Bands
    bb = BollingerBands(df['Close'], window=20, window_dev=2)
    indicators['bb_high'] = bb.bollinger_hband().tolist()
    indicators['bb_low'] = bb.bollinger_lband().tolist()
    indicators['bb_mid'] = bb.bollinger_mavg().tolist()
    
    return indicators

def calculate_metrics(df, info):
    """Calculate investment metrics"""
    current_price = df['Close'].iloc[-1]
    prev_close = df['Close'].iloc[-2] if len(df) > 1 else current_price
    
    # Price change
    price_change = current_price - prev_close
    price_change_pct = (price_change / prev_close) * 100 if prev_close > 0 else 0
    
    # Volatility (30-day)
    if len(df) >= 30:
        returns = df['Close'].pct_change().dropna()
        volatility = returns.tail(30).std() * np.sqrt(252) * 100  # Annualized
    else:
        volatility = None
    
    # 52-week range
    year_high = df['High'].max()
    year_low = df['Low'].min()
    
    # Metrics from info
    metrics = {
        'current_price': round(current_price, 2),
        'price_change': round(price_change, 2),
        'price_change_pct': round(price_change_pct, 2),
        'volume': int(df['Volume'].iloc[-1]),
        'avg_volume': int(df['Volume'].tail(30).mean()) if len(df) >= 30 else int(df['Volume'].mean()),
        'volatility': round(volatility, 2) if volatility else None,
        'year_high': round(year_high, 2),
        'year_low': round(year_low, 2),
        'pe_ratio': info.get('trailingPE'),
        'forward_pe': info.get('forwardPE'),
        'market_cap': info.get('marketCap'),
        'dividend_yield': info.get('dividendYield'),
        'beta': info.get('beta'),
        'eps': info.get('trailingEps'),
        'book_value': info.get('bookValue'),
        'price_to_book': info.get('priceToBook'),
        'profit_margin': info.get('profitMargins'),
        'revenue_growth': info.get('revenueGrowth'),
        'earnings_growth': info.get('earningsGrowth'),
    }
    
    return metrics

def get_earnings_qoq(ticker):
    """Get quarterly earnings, EPS, revenue and compare with expectations"""
    try:
        stock = yf.Ticker(ticker)
        income_stmt = stock.quarterly_income_stmt
        
        if income_stmt is None or income_stmt.empty:
            return None
        
        # Find Net Income row
        net_income_row = None
        search_terms = [
            'net income from continuing operation',
            'net income from continuing operations',
            'net income',
            'total net income',
            'income from continuing operations',
            'normalized income'
        ]
        
        for term in search_terms:
            for idx in income_stmt.index:
                idx_str = str(idx).lower()
                if term in idx_str:
                    net_income_row = income_stmt.loc[idx]
                    break
            if net_income_row is not None:
                break
        
        # Find Revenue row
        revenue_row = None
        for idx in income_stmt.index:
            idx_str = str(idx).lower()
            if 'total revenue' in idx_str:
                revenue_row = income_stmt.loc[idx]
                break
        
        # Find EPS row
        eps_row = None
        for idx in income_stmt.index:
            idx_str = str(idx).lower()
            if 'diluted eps' in idx_str:
                eps_row = income_stmt.loc[idx]
                break
            elif 'basic eps' in idx_str and eps_row is None:
                eps_row = income_stmt.loc[idx]
        
        if net_income_row is None:
            print(f"Could not find Net Income row for {ticker}")
            # Try to use first available row as fallback
            if len(income_stmt.index) > 0:
                net_income_row = income_stmt.iloc[0]
                print(f"Using fallback row: {income_stmt.index[0]}")
            else:
                return None
        
        if len(net_income_row) < 2:
            print(f"Not enough data columns: {len(net_income_row)}")
            return None
        
        # Get earnings estimates
        estimates_df = None
        try:
            estimates_df = stock.earnings_dates
        except:
            pass
        
        # Get quarters (columns are dates, most recent first)
        quarters = []
        earnings_data = []
        revenue_data = []
        eps_data = []
        eps_estimates = []
        eps_reported = []
        eps_surprise = []
        
        for col in income_stmt.columns:
            quarter_date = pd.Timestamp(col)
            # Format as YYYY-Q1, Q2, Q3, Q4
            quarter_num = (quarter_date.month - 1) // 3 + 1
            quarter_str = f"{quarter_date.year}-Q{quarter_num}"
            quarters.append(quarter_str)
            
            # Net Income
            earnings_data.append(float(net_income_row[col]) if pd.notna(net_income_row[col]) else None)
            
            # Revenue
            if revenue_row is not None:
                revenue_data.append(float(revenue_row[col]) if pd.notna(revenue_row[col]) else None)
            else:
                revenue_data.append(None)
            
            # EPS
            if eps_row is not None:
                eps_data.append(float(eps_row[col]) if pd.notna(eps_row[col]) else None)
            else:
                eps_data.append(None)
            
            # Match with estimates (find closest earnings date)
            eps_est = None
            eps_rep = None
            eps_sur = None
            
            if estimates_df is not None and not estimates_df.empty:
                # Find matching quarter in estimates
                for est_date in estimates_df.index:
                    est_quarter = pd.Timestamp(est_date)
                    # Normalize both timestamps to be timezone-naive for comparison
                    if est_quarter.tz is not None:
                        est_quarter = est_quarter.tz_localize(None)
                    if quarter_date.tz is not None:
                        quarter_date_naive = quarter_date.tz_localize(None)
                    else:
                        quarter_date_naive = quarter_date
                    
                    est_q_num = (est_quarter.month - 1) // 3 + 1
                    est_q_str = f"{est_quarter.year}-Q{est_q_num}"
                    
                    # Match by quarter (allow some date flexibility)
                    try:
                        days_diff = abs((est_quarter - quarter_date_naive).days)
                    except:
                        days_diff = 999
                    
                    if est_q_str == quarter_str or days_diff < 45:
                        if 'EPS Estimate' in estimates_df.columns:
                            eps_est = float(estimates_df.loc[est_date, 'EPS Estimate']) if pd.notna(estimates_df.loc[est_date, 'EPS Estimate']) else None
                        if 'Reported EPS' in estimates_df.columns:
                            eps_rep = float(estimates_df.loc[est_date, 'Reported EPS']) if pd.notna(estimates_df.loc[est_date, 'Reported EPS']) else None
                        if 'Surprise(%)' in estimates_df.columns:
                            eps_sur = float(estimates_df.loc[est_date, 'Surprise(%)']) if pd.notna(estimates_df.loc[est_date, 'Surprise(%)']) else None
                        break
            
            eps_estimates.append(eps_est)
            eps_reported.append(eps_rep)
            eps_surprise.append(eps_sur)
        
        # Calculate QoQ changes for earnings
        earnings_qoq_changes = []
        earnings_qoq_changes_pct = []
        
        # Calculate QoQ changes for revenue
        revenue_qoq_changes = []
        revenue_qoq_changes_pct = []
        
        # Calculate QoQ changes for EPS
        eps_qoq_changes = []
        eps_qoq_changes_pct = []
        
        for i in range(len(earnings_data)):
            if i == 0:
                earnings_qoq_changes.append(None)
                earnings_qoq_changes_pct.append(None)
                revenue_qoq_changes.append(None)
                revenue_qoq_changes_pct.append(None)
                eps_qoq_changes.append(None)
                eps_qoq_changes_pct.append(None)
            else:
                # Earnings QoQ
                current_earn = earnings_data[i]
                previous_earn = earnings_data[i-1]
                if current_earn is not None and previous_earn is not None and previous_earn != 0:
                    change = current_earn - previous_earn
                    change_pct = (change / abs(previous_earn)) * 100
                    earnings_qoq_changes.append(round(change / 1e9, 2))
                    earnings_qoq_changes_pct.append(round(change_pct, 2))
                else:
                    earnings_qoq_changes.append(None)
                    earnings_qoq_changes_pct.append(None)
                
                # Revenue QoQ
                current_rev = revenue_data[i]
                previous_rev = revenue_data[i-1]
                if current_rev is not None and previous_rev is not None and previous_rev != 0:
                    change = current_rev - previous_rev
                    change_pct = (change / abs(previous_rev)) * 100
                    revenue_qoq_changes.append(round(change / 1e9, 2))
                    revenue_qoq_changes_pct.append(round(change_pct, 2))
                else:
                    revenue_qoq_changes.append(None)
                    revenue_qoq_changes_pct.append(None)
                
                # EPS QoQ
                current_eps = eps_data[i]
                previous_eps = eps_data[i-1]
                if current_eps is not None and previous_eps is not None and previous_eps != 0:
                    change = current_eps - previous_eps
                    change_pct = (change / abs(previous_eps)) * 100
                    eps_qoq_changes.append(round(change, 2))
                    eps_qoq_changes_pct.append(round(change_pct, 2))
                else:
                    eps_qoq_changes.append(None)
                    eps_qoq_changes_pct.append(None)
        
        # Format earnings and revenue in billions
        earnings_formatted = [round(e / 1e9, 2) if e is not None else None for e in earnings_data]
        revenue_formatted = [round(r / 1e9, 2) if r is not None else None for r in revenue_data]
        
        return {
            'quarters': quarters,
            'earnings': earnings_formatted,  # In billions
            'earnings_qoq_change': earnings_qoq_changes,
            'earnings_qoq_change_pct': earnings_qoq_changes_pct,
            'revenue': revenue_formatted,  # In billions
            'revenue_qoq_change': revenue_qoq_changes,
            'revenue_qoq_change_pct': revenue_qoq_changes_pct,
            'eps': eps_data,
            'eps_qoq_change': eps_qoq_changes,
            'eps_qoq_change_pct': eps_qoq_changes_pct,
            'eps_estimate': eps_estimates,
            'eps_reported': eps_reported,
            'eps_surprise_pct': eps_surprise
        }
    except Exception as e:
        print(f"Error fetching earnings for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        # Return None to indicate failure
        return None

def analyze_sentiment(text):
    """Analyze sentiment of text using VADER"""
    if not text or len(text.strip()) == 0:
        return {'sentiment': 'neutral', 'score': 0.0, 'label': 'Neutrální'}
    
    scores = sentiment_analyzer.polarity_scores(text)
    compound = scores['compound']
    
    if compound >= 0.05:
        sentiment = 'positive'
        label = 'Pozitivní'
    elif compound <= -0.05:
        sentiment = 'negative'
        label = 'Negativní'
    else:
        sentiment = 'neutral'
        label = 'Neutrální'
    
    return {
        'sentiment': sentiment,
        'score': round(compound, 3),
        'label': label,
        'positive': round(scores['pos'], 3),
        'negative': round(scores['neg'], 3),
        'neutral': round(scores['neu'], 3)
    }

def get_financials_data(ticker):
    """Get comprehensive financial data for Financials tab"""
    try:
        stock = yf.Ticker(ticker)
        time.sleep(0.3)  # Rate limiting
        
        # Get company info for sector/industry context
        try:
            info = stock.info
            sector = info.get('sector', 'N/A')
            industry = info.get('industry', 'N/A')
        except:
            info = {}
            sector = 'N/A'
            industry = 'N/A'
        
        financials = {
            'executive_snapshot': {},
            'income_statement': {'quarterly': [], 'annual': []},
            'margins': {'quarterly': [], 'annual': []},
            'cash_flow': {'quarterly': [], 'annual': []},
            'balance_sheet': {},
            'segments': [],
            'red_flags': [],
            'fundamentals_verdict': 'neutral',
            'main_verdict_sentence': '',
            'company_stage': 'unknown',
            'sector': sector,
            'industry': industry
        }
        
        # Get income statements
        quarterly_income = stock.quarterly_income_stmt
        annual_income = stock.financials
        
        # Get cash flow statements
        quarterly_cf = stock.quarterly_cashflow
        annual_cf = stock.cashflow
        
        # Get balance sheet
        quarterly_bs = stock.quarterly_balance_sheet
        annual_bs = stock.balance_sheet
        
        # Helper function to find row in statement
        def find_row(df, search_terms):
            if df is None or df.empty:
                return None
            for term in search_terms:
                for idx in df.index:
                    if term in str(idx).lower():
                        return df.loc[idx]
            return None
        
        # Calculate TTM (Trailing Twelve Months) values
        def calculate_ttm(quarterly_data):
            if quarterly_data is None or quarterly_data.empty:
                return None
            # Sum last 4 quarters
            if len(quarterly_data.columns) >= 4:
                return quarterly_data.iloc[:, :4].sum(axis=1)
            return None
        
        # Get Revenue
        revenue_row_q = find_row(quarterly_income, ['total revenue', 'revenue', 'net sales', 'sales'])
        revenue_row_a = find_row(annual_income, ['total revenue', 'revenue', 'net sales', 'sales'])
        
        # Get Net Income
        net_income_row_q = find_row(quarterly_income, ['net income', 'total net income', 'income from continuing operations'])
        net_income_row_a = find_row(annual_income, ['net income', 'total net income', 'income from continuing operations'])
        
        # Get Operating Cash Flow
        ocf_row_q = find_row(quarterly_cf, ['operating cash flow', 'total cash from operating activities', 'operating activities'])
        ocf_row_a = find_row(annual_cf, ['operating cash flow', 'total cash from operating activities', 'operating activities'])
        
        # Get CapEx
        capex_row_q = find_row(quarterly_cf, ['capital expenditures', 'capex', 'capital expenditure'])
        capex_row_a = find_row(annual_cf, ['capital expenditures', 'capex', 'capital expenditure'])
        
        # Get Free Cash Flow (Operating CF - CapEx)
        def calculate_fcf(ocf_row, capex_row):
            if ocf_row is None or capex_row is None:
                return None
            try:
                # Both are pandas Series with same index (quarterly dates)
                fcf = ocf_row.copy()
                for i in range(min(len(fcf), len(capex_row))):
                    if pd.notna(fcf.iloc[i]) and pd.notna(capex_row.iloc[i]):
                        fcf.iloc[i] = float(fcf.iloc[i]) - abs(float(capex_row.iloc[i]))
                    else:
                        fcf.iloc[i] = None
                return fcf
            except:
                return None
        
        fcf_row_q = calculate_fcf(ocf_row_q, capex_row_q) if ocf_row_q is not None and capex_row_q is not None else None
        fcf_row_a = calculate_fcf(ocf_row_a, capex_row_a) if ocf_row_a is not None and capex_row_a is not None else None
        
        # Calculate TTM values (sum of last 4 quarters)
        revenue_ttm = None
        net_income_ttm = None
        fcf_ttm = None
        
        if revenue_row_q is not None and len(revenue_row_q) >= 4:
            try:
                # revenue_row_q is a pandas Series, access values directly
                revenue_ttm = float(revenue_row_q.iloc[:4].sum())
            except:
                try:
                    revenue_ttm = sum([float(v) for v in list(revenue_row_q.values)[:4] if pd.notna(v)])
                except:
                    pass
        
        if net_income_row_q is not None and len(net_income_row_q) >= 4:
            try:
                net_income_ttm = float(net_income_row_q.iloc[:4].sum())
            except:
                try:
                    net_income_ttm = sum([float(v) for v in list(net_income_row_q.values)[:4] if pd.notna(v)])
                except:
                    pass
        
        if fcf_row_q is not None and len(fcf_row_q) >= 4:
            try:
                fcf_ttm = float(fcf_row_q.iloc[:4].sum())
            except:
                try:
                    fcf_ttm = sum([float(v) for v in list(fcf_row_q.values)[:4] if pd.notna(v)])
                except:
                    pass
        
        # Calculate YoY growth (compare current quarter to same quarter last year)
        def calculate_yoy_growth(current_row, periods_ago=4):
            if current_row is None or len(current_row) < periods_ago + 1:
                return None
            try:
                # Get most recent (first) and 4 quarters ago
                current = float(current_row.iloc[0])
                previous = float(current_row.iloc[periods_ago])
                if previous != 0 and not pd.isna(current) and not pd.isna(previous):
                    return ((current - previous) / abs(previous)) * 100
            except (IndexError, ValueError, TypeError):
                pass
            return None
        
        revenue_yoy = calculate_yoy_growth(revenue_row_q)
        net_income_yoy = calculate_yoy_growth(net_income_row_q)
        
        # Get Gross Margin
        gross_profit_row_q = find_row(quarterly_income, ['gross profit', 'total gross profit'])
        gross_margin_q = None
        if gross_profit_row_q is not None and revenue_row_q is not None:
            try:
                if len(gross_profit_row_q) > 0 and len(revenue_row_q) > 0:
                    gross_profit = float(gross_profit_row_q.iloc[0] if hasattr(gross_profit_row_q, 'iloc') else list(gross_profit_row_q.values())[0])
                    revenue = float(revenue_row_q.iloc[0] if hasattr(revenue_row_q, 'iloc') else list(revenue_row_q.values())[0])
                    if revenue != 0:
                        gross_margin_q = (gross_profit / revenue) * 100
            except:
                pass
        
        # Get Operating Margin
        operating_income_row_q = find_row(quarterly_income, ['operating income', 'income from operations', 'operating profit'])
        operating_margin_q = None
        if operating_income_row_q is not None and revenue_row_q is not None:
            try:
                if len(operating_income_row_q) > 0 and len(revenue_row_q) > 0:
                    op_income = float(operating_income_row_q.iloc[0] if hasattr(operating_income_row_q, 'iloc') else list(operating_income_row_q.values())[0])
                    revenue = float(revenue_row_q.iloc[0] if hasattr(revenue_row_q, 'iloc') else list(revenue_row_q.values())[0])
                    if revenue != 0:
                        operating_margin_q = (op_income / revenue) * 100
            except:
                pass
        
        # Get Net Margin
        net_margin_q = None
        if net_income_row_q is not None and revenue_row_q is not None:
            try:
                if len(net_income_row_q) > 0 and len(revenue_row_q) > 0:
                    net_income = float(net_income_row_q.iloc[0] if hasattr(net_income_row_q, 'iloc') else list(net_income_row_q.values())[0])
                    revenue = float(revenue_row_q.iloc[0] if hasattr(revenue_row_q, 'iloc') else list(revenue_row_q.values())[0])
                    if revenue != 0:
                        net_margin_q = (net_income / revenue) * 100
            except:
                pass
        
        # Get Debt
        total_debt_row = find_row(quarterly_bs, ['total debt', 'total liabilities', 'long term debt'])
        total_debt = None
        if total_debt_row is not None and len(total_debt_row) > 0:
            try:
                total_debt = float(total_debt_row.iloc[0] if hasattr(total_debt_row, 'iloc') else list(total_debt_row.values())[0])
            except:
                pass
        
        # Calculate Debt/FCF ratio
        debt_fcf_ratio = None
        if total_debt is not None and fcf_ttm is not None and fcf_ttm != 0:
            debt_fcf_ratio = abs(total_debt / fcf_ttm)
        
        # FCF Margin
        fcf_margin = None
        if fcf_ttm is not None and revenue_ttm is not None and revenue_ttm != 0:
            fcf_margin = (fcf_ttm / revenue_ttm) * 100
        
        # Build Executive Snapshot
        financials['executive_snapshot'] = {
            'revenue_ttm': revenue_ttm,
            'revenue_yoy': revenue_yoy,
            'net_income_ttm': net_income_ttm,
            'net_income_yoy': net_income_yoy,
            'fcf_ttm': fcf_ttm,
            'fcf_margin': fcf_margin,
            'gross_margin': gross_margin_q,
            'debt_fcf_ratio': debt_fcf_ratio
        }
        
        # Build Income Statement data for charts
        if revenue_row_q is not None and quarterly_income is not None:
            for i, col in enumerate(quarterly_income.columns[:8]):  # Last 8 quarters
                try:
                    quarter_date = pd.Timestamp(col)
                    quarter_str = f"{quarter_date.year}-Q{(quarter_date.month - 1) // 3 + 1}"
                    revenue_val = float(revenue_row_q.iloc[i]) if i < len(revenue_row_q) else None
                    net_income_val = float(net_income_row_q.iloc[i]) if net_income_row_q is not None and i < len(net_income_row_q) else None
                    
                    if revenue_val is not None and not pd.isna(revenue_val):
                        financials['income_statement']['quarterly'].append({
                            'quarter': quarter_str,
                            'date': quarter_date.strftime('%Y-%m-%d'),
                            'revenue': revenue_val,
                            'net_income': net_income_val if net_income_val is not None and not pd.isna(net_income_val) else None
                        })
                except (IndexError, ValueError, TypeError):
                    continue
        
        # Build Margins data
        if gross_margin_q is not None or operating_margin_q is not None or net_margin_q is not None:
            financials['margins']['quarterly'].append({
                'gross_margin': gross_margin_q,
                'operating_margin': operating_margin_q,
                'net_margin': net_margin_q
            })
        
        # Build Cash Flow data
        if ocf_row_q is not None and quarterly_cf is not None:
            for i, col in enumerate(quarterly_cf.columns[:8]):
                try:
                    quarter_date = pd.Timestamp(col)
                    quarter_str = f"{quarter_date.year}-Q{(quarter_date.month - 1) // 3 + 1}"
                    ocf_val = float(ocf_row_q.iloc[i]) if i < len(ocf_row_q) else None
                    capex_val = float(capex_row_q.iloc[i]) if capex_row_q is not None and i < len(capex_row_q) else None
                    fcf_val = float(fcf_row_q.iloc[i]) if fcf_row_q is not None and i < len(fcf_row_q) else None
                    
                    if ocf_val is not None and not pd.isna(ocf_val):
                        financials['cash_flow']['quarterly'].append({
                            'quarter': quarter_str,
                            'date': quarter_date.strftime('%Y-%m-%d'),
                            'operating_cf': ocf_val,
                            'capex': abs(capex_val) if capex_val is not None and not pd.isna(capex_val) else None,
                            'fcf': fcf_val if fcf_val is not None and not pd.isna(fcf_val) else None
                        })
                except (IndexError, ValueError, TypeError):
                    continue
        
        # Build Balance Sheet (simplified)
        cash_row = find_row(quarterly_bs, ['cash and cash equivalents', 'cash', 'cash and short term investments'])
        equity_row = find_row(quarterly_bs, ['total stockholders equity', 'total equity', 'stockholders equity'])
        current_assets_row = find_row(quarterly_bs, ['total current assets'])
        current_liabilities_row = find_row(quarterly_bs, ['total current liabilities'])
        
        cash = None
        equity = None
        current_ratio = None
        
        if cash_row is not None and len(cash_row) > 0:
            try:
                cash = float(cash_row.iloc[0] if hasattr(cash_row, 'iloc') else list(cash_row.values())[0])
            except:
                pass
        
        if equity_row is not None and len(equity_row) > 0:
            try:
                equity = float(equity_row.iloc[0] if hasattr(equity_row, 'iloc') else list(equity_row.values())[0])
            except:
                pass
        
        if current_assets_row is not None and current_liabilities_row is not None:
            try:
                if len(current_assets_row) > 0 and len(current_liabilities_row) > 0:
                    ca = float(current_assets_row.iloc[0] if hasattr(current_assets_row, 'iloc') else list(current_assets_row.values())[0])
                    cl = float(current_liabilities_row.iloc[0] if hasattr(current_liabilities_row, 'iloc') else list(current_liabilities_row.values())[0])
                    if cl != 0:
                        current_ratio = ca / cl
            except:
                pass
        
        net_debt = None
        if total_debt is not None and cash is not None:
            net_debt = total_debt - cash
        
        financials['balance_sheet'] = {
            'cash': cash,
            'total_debt': total_debt,
            'net_debt': net_debt,
            'equity': equity,
            'current_ratio': current_ratio
        }
        
        # Generate Red Flags
        red_flags = []
        
        # Check for declining revenue
        # Note: quarterly data is ordered from newest to oldest (revenues[0] = most recent)
        # Data: [Q3, Q2, Q1] where Q3 is newest
        # Revenue is declining if: Q3 > Q2 > Q1 (each newer quarter is larger than older)
        # So: revenues[0] > revenues[1] > revenues[2]
        if len(financials['income_statement']['quarterly']) >= 3:
            revenues = [q['revenue'] for q in financials['income_statement']['quarterly'][:3] if q.get('revenue') is not None]
            if len(revenues) >= 3:
                # Check if revenue is declining: newest > previous > older (i.e., revenues[0] > revenues[1] > revenues[2])
                # This means each newer quarter is larger than the older one (so revenue is declining over time)
                is_declining = all(revenues[i] > revenues[i+1] for i in range(len(revenues)-1))
                if is_declining:
                    red_flags.append({
                        'type': 'revenue_decline',
                        'severity': 'high',
                        'message': 'Tržby klesají 3 kvartály po sobě'
                    })
        
        # Check FCF < Net Income
        if fcf_ttm is not None and net_income_ttm is not None and fcf_ttm < net_income_ttm:
            red_flags.append({
                'type': 'fcf_quality',
                'severity': 'medium',
                'message': 'FCF < Net Income (možné accounting issues)'
            })
        
        # Check rising debt + falling margins
        if debt_fcf_ratio is not None and debt_fcf_ratio > 3 and gross_margin_q is not None:
            red_flags.append({
                'type': 'debt_margin',
                'severity': 'high',
                'message': 'Rostoucí dluh + potenciálně klesající marže'
            })
        
        financials['red_flags'] = red_flags
        
        # Detect Company Stage
        company_stage = 'unknown'
        stage_indicators = []
        
        # Early-stage: Very low/no revenue, negative earnings, high burn rate
        if revenue_ttm is not None and revenue_ttm < 100_000_000:  # Less than $100M
            if net_income_ttm is not None and net_income_ttm < 0:
                if fcf_ttm is not None and fcf_ttm < 0:
                    company_stage = 'early_stage'
                    stage_indicators.append('pre_revenue')
        
        # Growth: Growing revenue, may be unprofitable but improving
        if revenue_yoy and revenue_yoy > 20:
            if net_income_ttm is None or net_income_ttm < 0:
                if net_income_yoy and net_income_yoy > 0:  # Improving losses
                    company_stage = 'growth'
                    stage_indicators.append('high_growth')
        
        # Mature: Stable revenue, positive earnings, positive FCF
        if revenue_ttm and revenue_ttm > 1_000_000_000:  # Over $1B
            if net_income_ttm and net_income_ttm > 0:
                if fcf_ttm and fcf_ttm > 0:
                    if revenue_yoy and -5 < revenue_yoy < 15:  # Moderate growth
                        company_stage = 'mature'
                        stage_indicators.append('stable')
        
        # Turnaround: Declining revenue, negative earnings, trying to recover
        if revenue_yoy and revenue_yoy < -10:
            if net_income_ttm and net_income_ttm < 0:
                company_stage = 'turnaround'
                stage_indicators.append('declining')
        
        # Default to growth if revenue is growing
        if company_stage == 'unknown' and revenue_yoy and revenue_yoy > 10:
            company_stage = 'growth'
        
        financials['company_stage'] = company_stage
        
        # Generate Fundamentals Verdict
        verdict_score = 0
        if revenue_yoy and revenue_yoy > 0:
            verdict_score += 1
        if net_income_yoy and net_income_yoy > 0:
            verdict_score += 1
        if fcf_ttm and fcf_ttm > 0:
            verdict_score += 1
        if gross_margin_q and gross_margin_q > 30:
            verdict_score += 1
        if debt_fcf_ratio and debt_fcf_ratio < 2:
            verdict_score += 1
        
        if verdict_score >= 4:
            financials['fundamentals_verdict'] = 'strong'
        elif verdict_score >= 2:
            financials['fundamentals_verdict'] = 'neutral'
        else:
            financials['fundamentals_verdict'] = 'weak'
        
        # Generate Main Verdict Sentence
        verdict_parts = []
        
        # Revenue assessment
        if revenue_yoy:
            if revenue_yoy > 15:
                verdict_parts.append('Silné tržby')
            elif revenue_yoy > 5:
                verdict_parts.append('Rostoucí tržby')
            elif revenue_yoy > 0:
                verdict_parts.append('Mírně rostoucí tržby')
            else:
                verdict_parts.append('Klesající tržby')
        
        # Earnings assessment
        if net_income_ttm:
            if net_income_ttm > 0:
                if net_income_yoy and net_income_yoy > 10:
                    verdict_parts.append('zisk roste rychle')
                elif net_income_yoy and net_income_yoy > 0:
                    verdict_parts.append('zisk roste')
                else:
                    verdict_parts.append('zisk je stabilní')
            else:
                if company_stage == 'early_stage':
                    verdict_parts.append('ztráty jsou očekávané (early-stage)')
                elif net_income_yoy and net_income_yoy > 0:
                    verdict_parts.append('ztráty se zmenšují')
                else:
                    verdict_parts.append('ztráty pokračují')
        
        # Cash flow assessment
        if fcf_ttm:
            if fcf_ttm > 0:
                if fcf_ttm >= net_income_ttm if net_income_ttm else False:
                    verdict_parts.append('výborný cash flow')
                else:
                    verdict_parts.append('pozitivní cash flow')
            else:
                if company_stage == 'early_stage':
                    verdict_parts.append('burn rate je očekávaný')
                else:
                    verdict_parts.append('negativní cash flow')
        
        # Combine into sentence
        if len(verdict_parts) >= 2:
            main_sentence = f"{verdict_parts[0]}, {verdict_parts[1]}"
            if len(verdict_parts) >= 3:
                main_sentence += f" → {verdict_parts[2]}"
        elif len(verdict_parts) == 1:
            main_sentence = verdict_parts[0]
        else:
            main_sentence = "Finanční data vyžadují další analýzu."
        
        # Add context based on stage
        if company_stage == 'early_stage':
            main_sentence += " (Pre-revenue / early-stage company - ztráty jsou očekávané)"
        elif company_stage == 'growth':
            if net_income_ttm and net_income_ttm < 0:
                main_sentence += " (Growth phase - investice do růstu)"
        elif company_stage == 'turnaround':
            main_sentence += " (Turnaround - firma se snaží zotavit)"
        
        financials['main_verdict_sentence'] = main_sentence
        
        # Add trend indicators to executive snapshot
        financials['executive_snapshot']['revenue_trend'] = 'improving' if revenue_yoy and revenue_yoy > 0 else 'deteriorating' if revenue_yoy and revenue_yoy < 0 else 'stable'
        financials['executive_snapshot']['earnings_trend'] = 'improving' if net_income_yoy and net_income_yoy > 0 else 'deteriorating' if net_income_yoy and net_income_yoy < 0 else 'stable'
        financials['executive_snapshot']['fcf_trend'] = 'improving' if fcf_ttm and fcf_ttm > 0 else 'deteriorating' if fcf_ttm and fcf_ttm < 0 else 'stable'
        
        return financials
        
    except Exception as e:
        print(f"Error fetching financials for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def generate_news_summary(news_list, ticker):
    """Generate AI-powered summary of news articles"""
    if not news_list or len(news_list) == 0:
        return {
            'summary': 'No recent news available for this stock.',
            'key_points': [],
            'overall_sentiment': 'neutral',
            'sentiment_score': 0.0,
            'total_articles': 0
        }
    
    # Collect all text for analysis
    all_titles = []
    all_summaries = []
    sentiment_scores = []
    positive_articles = []
    negative_articles = []
    neutral_articles = []
    
    for article in news_list:
        title = article.get('title', '')
        summary = article.get('summary', '')
        sentiment = article.get('sentiment', 'neutral')
        sentiment_score = article.get('sentiment_score', 0.0)
        
        if title:
            all_titles.append(title)
        if summary and summary != 'No summary available':
            all_summaries.append(summary)
        
        sentiment_scores.append(sentiment_score)
        
        if sentiment == 'positive':
            positive_articles.append(article)
        elif sentiment == 'negative':
            negative_articles.append(article)
        else:
            neutral_articles.append(article)
    
    # Calculate overall sentiment
    avg_sentiment_score = sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0.0
    
    if avg_sentiment_score >= 0.05:
        overall_sentiment = 'positive'
        sentiment_label = 'Pozitivní'
    elif avg_sentiment_score <= -0.05:
        overall_sentiment = 'negative'
        sentiment_label = 'Negativní'
    else:
        overall_sentiment = 'neutral'
        sentiment_label = 'Neutrální'
    
    # Extract key points from titles and summaries
    key_points = []
    
    # Get most important positive points
    if positive_articles:
        for article in positive_articles[:3]:
            title = article.get('title', '')
            if title and len(title) > 20:
                key_points.append({
                    'text': title,
                    'sentiment': 'positive',
                    'source': article.get('publisher', 'StockTitan')
                })
    
    # Get most important negative points
    if negative_articles:
        for article in negative_articles[:3]:
            title = article.get('title', '')
            if title and len(title) > 20:
                key_points.append({
                    'text': title,
                    'sentiment': 'negative',
                    'source': article.get('publisher', 'StockTitan')
                })
    
    # If not enough key points, add from neutral or all articles
    if len(key_points) < 5:
        remaining = [a for a in news_list if a.get('title', '') not in [kp['text'] for kp in key_points]]
        for article in remaining[:5 - len(key_points)]:
            title = article.get('title', '')
            if title and len(title) > 20:
                key_points.append({
                    'text': title,
                    'sentiment': article.get('sentiment', 'neutral'),
                    'source': article.get('publisher', 'StockTitan')
                })
    
    # Generate summary text
    total_articles = len(news_list)
    positive_count = len(positive_articles)
    negative_count = len(negative_articles)
    neutral_count = len(neutral_articles)
    
    summary_parts = []
    summary_parts.append(f"Shrnutí {total_articles} nejnovějších článků o {ticker}:")
    summary_parts.append("")
    
    if positive_count > 0:
        summary_parts.append(f"📈 Pozitivní zprávy ({positive_count}): Většina pozitivních zpráv se zaměřuje na růst, inovace a pozitivní výhled společnosti.")
    if negative_count > 0:
        summary_parts.append(f"📉 Negativní zprávy ({negative_count}): Některé zprávy poukazují na výzvy nebo rizika.")
    if neutral_count > 0:
        summary_parts.append(f"📊 Neutrální zprávy ({neutral_count}): Informační články bez výrazného sentimentu.")
    
    summary_parts.append("")
    summary_parts.append(f"Celkový sentiment: {sentiment_label} (skóre: {avg_sentiment_score:.2f})")
    
    if overall_sentiment == 'positive':
        summary_parts.append("Obecně převládá pozitivní nálada v médiích ohledně této akcie.")
    elif overall_sentiment == 'negative':
        summary_parts.append("V médiích převládá spíše negativní nálada ohledně této akcie.")
    else:
        summary_parts.append("Sentiment v médiích je převážně neutrální.")
    
    summary_text = "\n".join(summary_parts)
    
    return {
        'summary': summary_text,
        'key_points': key_points[:10],  # Limit to 10 key points
        'overall_sentiment': overall_sentiment,
        'sentiment_label': sentiment_label,
        'sentiment_score': round(avg_sentiment_score, 3),
        'total_articles': total_articles,
        'positive_count': positive_count,
        'negative_count': negative_count,
        'neutral_count': neutral_count,
        'sentiment_breakdown': {
            'positive': round(positive_count / total_articles * 100, 1) if total_articles > 0 else 0,
            'negative': round(negative_count / total_articles * 100, 1) if total_articles > 0 else 0,
            'neutral': round(neutral_count / total_articles * 100, 1) if total_articles > 0 else 0
        }
    }

def normalize_date(date_str):
    """Normalize date string to YYYY-MM-DD HH:MM format"""
    if not date_str or date_str == 'N/A' or date_str.strip() == '':
        return None
    
    try:
        # Try parsing RFC 2822 format (from RSS feeds) FIRST - e.g., "Sun, 14 Dec 2025 04:19:00 GMT"
        try:
            import email.utils
            parsed_time = email.utils.parsedate_tz(date_str)
            if parsed_time:
                timestamp = email.utils.mktime_tz(parsed_time)
                dt = datetime.fromtimestamp(timestamp)
                return dt.strftime('%Y-%m-%d %H:%M')
        except Exception as e:
            pass
        
        # Try parsing ISO format
        if 'T' in date_str:
            try:
                dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                return dt.strftime('%Y-%m-%d %H:%M')
            except:
                pass
        
        # Try common date formats
        for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d', '%d.%m.%Y %H:%M', '%d.%m.%Y', '%B %d, %Y', '%b %d, %Y']:
            try:
                dt = datetime.strptime(date_str.strip(), fmt)
                return dt.strftime('%Y-%m-%d %H:%M')
            except:
                continue
        
        # If it contains relative time like "2 hours ago", return as is (frontend will handle it)
        if any(keyword in date_str.lower() for keyword in ['ago', 'hour', 'day', 'minute', 'just now']):
            return date_str
        
        # If all parsing fails, return original string
        return date_str
    except Exception as e:
        print(f"Error normalizing date '{date_str}': {str(e)}")
        return date_str

def get_stock_news(ticker, max_news=10):
    """Get latest news for a stock from StockTitan and analyze sentiment"""
    try:
        analyzed_news = []
        
        # Method 1: Try RSS feed first (more reliable, less likely to be blocked)
        try:
            rss_url = "https://www.stocktitan.net/rss"
            feed = feedparser.parse(rss_url)
            
            for entry in feed.entries[:max_news * 5]:  # Projdeme více, abychom našli relevantní
                title = entry.get('title', '')
                summary = entry.get('summary', '') or entry.get('description', '')
                link = entry.get('link', '')
                published = entry.get('published', '') or entry.get('updated', '')
                
                # Filtrujeme podle tickeru v titulku, summary nebo linku
                # StockTitan má ticker v linku jako /news/TICKER/...
                link_upper = link.upper()
                if (ticker.upper() in title.upper() or 
                    ticker.upper() in summary.upper() or 
                    f"/news/{ticker.upper()}/" in link_upper or
                    f"/news/{ticker.upper()}-" in link_upper):
                    text_for_analysis = f"{title}. {summary}".strip()
                    sentiment_data = analyze_sentiment(text_for_analysis)
                    
                    # If no date from RSS, use current date as fallback
                    if not published or published.strip() == '':
                        published = datetime.now().strftime('%Y-%m-%d %H:%M')
                    
                    normalized_date = normalize_date(published) if published else None
                    published_str = normalized_date if normalized_date else datetime.now().strftime('%Y-%m-%d %H:%M')
                    
                    analyzed_news.append({
                        'title': title,
                        'summary': summary[:500] if summary else 'No summary available',
                        'publisher': 'StockTitan',
                        'link': link,
                        'published': published_str,
                        'sentiment': sentiment_data['sentiment'],
                        'sentiment_label': sentiment_data['label'],
                        'sentiment_score': sentiment_data['score'],
                        'sentiment_details': {
                            'positive': sentiment_data['positive'],
                            'negative': sentiment_data['negative'],
                            'neutral': sentiment_data['neutral']
                        }
                    })
                    
                    if len(analyzed_news) >= max_news:
                        break
            
            if analyzed_news:
                return analyzed_news
        except Exception as e:
            print(f"Error parsing RSS feed for {ticker}: {str(e)}")
        
        # Method 2: REMOVED - scraping causes 429 errors from StockTitan
        # StockTitan blocks scraping with "Too many requests" error
        # We only use RSS feed which is more reliable and less likely to be blocked
        
        # Only use StockTitan RSS feed - no scraping, no yfinance fallback
        # All news come from StockTitan RSS feed with AI sentiment analysis
        return analyzed_news
        
    except Exception as e:
        print(f"Error fetching news for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/stock/<ticker>')
def get_stock(ticker):
    period = request.args.get('period', '1y')
    
    data = get_stock_data(ticker.upper(), period)
    
    if data is None:
        return jsonify({'error': 'Stock not found or data unavailable'}), 404
    
    df = data['history']
    info = data['info']
    
    # Prepare chart data
    dates = df.index.strftime('%Y-%m-%d').tolist()
    chart_data = {
        'dates': dates,
        'open': df['Open'].round(2).fillna(0).tolist(),
        'high': df['High'].round(2).fillna(0).tolist(),
        'low': df['Low'].round(2).fillna(0).tolist(),
        'close': df['Close'].round(2).fillna(0).tolist(),
        'volume': df['Volume'].fillna(0).astype(int).tolist(),
    }
    
    # Calculate technical indicators
    indicators = calculate_technical_indicators(df)
    
    # Calculate metrics
    metrics = calculate_metrics(df, info)
    
    # Get earnings QoQ data
    earnings_qoq = get_earnings_qoq(ticker.upper())
    
    # Get news with sentiment analysis
    news = get_stock_news(ticker.upper(), max_news=10)
    
    # Generate AI news summary
    news_summary = generate_news_summary(news, ticker.upper())
    
    # Company info
    company_info = {
        'name': info.get('longName', ticker),
        'sector': info.get('sector'),
        'industry': info.get('industry'),
        'description': info.get('longBusinessSummary', ''),
    }
    
    # Clean all data for JSON (replace NaN with None)
    response_data = {
        'ticker': ticker.upper(),
        'chart_data': clean_for_json(chart_data),
        'indicators': clean_for_json(indicators),
        'metrics': clean_for_json(metrics),
        'company_info': clean_for_json(company_info),
        'earnings_qoq': clean_for_json(earnings_qoq) if earnings_qoq else None,
        'news': clean_for_json(news),
        'news_summary': clean_for_json(news_summary)
    }
    
    return jsonify(response_data)

@app.route('/api/search/<query>')
def search_stocks(query):
    """Simple stock search - returns suggestions"""
    # In a real app, you'd use a proper stock search API
    # For now, we'll just validate if the ticker exists
    try:
        stock = yf.Ticker(query.upper())
        info = stock.info
        if info and 'symbol' in info:
            return jsonify({
                'results': [{
                    'symbol': info.get('symbol'),
                    'name': info.get('longName', query.upper())
                }]
            })
    except:
        pass
    
    return jsonify({'results': []})

@app.route('/api/earnings-calendar')
def get_earnings_calendar():
    """Get earnings calendar for popular stocks"""
    try:
        # Reduced list of most popular stocks to speed up loading
        popular_tickers = [
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX',
            'JPM', 'V', 'JNJ', 'WMT', 'PG', 'MA', 'UNH', 'HD', 'DIS', 'BAC',
            'ADBE', 'PYPL', 'CMCSA', 'NKE', 'XOM', 'VZ', 'CVX', 'MRK', 'PFE'
        ]
        
        earnings_calendar = []
        today = datetime.now().date()
        future_date = today + timedelta(days=90)  # Next 90 days
        
        # Process stocks with minimal delays
        for i, ticker in enumerate(popular_tickers):
            try:
                stock = yf.Ticker(ticker)
                
                # Get earnings dates first (faster)
                earnings_dates = None
                try:
                    earnings_dates = stock.earnings_dates
                    if earnings_dates is not None and not earnings_dates.empty:
                        # Get company info only if we have earnings dates
                        info = {}
                        try:
                            info = stock.info
                        except:
                            info = {'longName': ticker, 'sector': 'N/A'}
                        
                        # Process each earnings date
                        for date_idx, row in earnings_dates.iterrows():
                            try:
                                earnings_date = pd.Timestamp(date_idx)
                                if hasattr(earnings_date, 'date'):
                                    earnings_date = earnings_date.date()
                                else:
                                    earnings_date = earnings_date.to_pydatetime().date()
                                
                                # Include future earnings and also recent past (last 7 days) for context
                                days_diff = (earnings_date - today).days
                                if days_diff >= -7 and days_diff <= 90:
                                    eps_estimate = None
                                    eps_reported = None
                                    surprise_pct = None
                                    
                                    if 'EPS Estimate' in row.index:
                                        eps_estimate = float(row['EPS Estimate']) if pd.notna(row['EPS Estimate']) else None
                                    if 'Reported EPS' in row.index:
                                        eps_reported = float(row['Reported EPS']) if pd.notna(row['Reported EPS']) else None
                                    if 'Surprise(%)' in row.index:
                                        surprise_pct = float(row['Surprise(%)']) if pd.notna(row['Surprise(%)']) else None
                                    
                                    earnings_calendar.append({
                                        'ticker': ticker,
                                        'company_name': info.get('longName', ticker),
                                        'sector': info.get('sector', 'N/A'),
                                        'earnings_date': earnings_date.strftime('%Y-%m-%d'),
                                        'earnings_date_display': earnings_date.strftime('%B %d, %Y'),
                                        'eps_estimate': eps_estimate,
                                        'eps_reported': eps_reported,
                                        'surprise_pct': surprise_pct,
                                        'is_past': earnings_date < today
                                    })
                            except Exception as e:
                                print(f"Error processing earnings date for {ticker}: {str(e)}")
                                continue
                except Exception as e:
                    print(f"Error fetching earnings_dates for {ticker}: {str(e)}")
                    continue
                
                # Small delay only every 5 stocks to avoid rate limiting
                if (i + 1) % 5 == 0:
                    time.sleep(0.2)
                
            except Exception as e:
                print(f"Error fetching earnings for {ticker}: {str(e)}")
                continue
        
        # Sort by earnings date
        earnings_calendar.sort(key=lambda x: x['earnings_date'])
        
        return jsonify({
            'earnings': clean_for_json(earnings_calendar),
            'total': len(earnings_calendar)
        })
        
    except Exception as e:
        print(f"Error in earnings calendar: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to fetch earnings calendar: {str(e)}', 'earnings': [], 'total': 0}), 500

@app.route('/api/alerts-dashboard', methods=['POST'])
def get_alerts_dashboard():
    """Get all alerts (earnings, news) for watchlist stocks"""
    try:
        data = request.get_json()
        watchlist = data.get('watchlist', [])
        
        if not watchlist:
            return jsonify({
                'earnings_alerts': [],
                'news_alerts': [],
                'total': 0
            })
        
        today = datetime.now().date()
        earnings_alerts = []
        news_alerts = []
        
        # Process each ticker in watchlist
        for i, ticker in enumerate(watchlist[:20]):  # Limit to 20 to avoid timeout
            try:
                stock = yf.Ticker(ticker)
                
                # Check for upcoming earnings (next 90 days for better coverage)
                try:
                    earnings_dates = stock.earnings_dates
                    if earnings_dates is not None and not earnings_dates.empty:
                        info = {}
                        try:
                            info = stock.info
                        except:
                            info = {'longName': ticker}
                        
                        # Try to find next earnings date (using same logic as earnings calendar)
                        found_earnings = False
                        for date_idx, row in earnings_dates.iterrows():
                            try:
                                earnings_date = pd.Timestamp(date_idx)
                                # Handle timezone-aware dates the same way as earnings calendar
                                if hasattr(earnings_date, 'date'):
                                    earnings_date = earnings_date.date()
                                else:
                                    earnings_date = earnings_date.to_pydatetime().date()
                                
                                days_diff = (earnings_date - today).days
                                # Alert for earnings in next 90 days (extended for better coverage)
                                # Also include past earnings from last 7 days (recently reported)
                                if -7 <= days_diff <= 90:
                                    earnings_alerts.append({
                                        'ticker': ticker,
                                        'company_name': info.get('longName', ticker),
                                        'earnings_date': earnings_date.strftime('%Y-%m-%d'),
                                        'earnings_date_display': earnings_date.strftime('%B %d, %Y'),
                                        'days_until': days_diff,
                                        'priority': 'high' if days_diff <= 2 else ('medium' if days_diff <= 7 else 'low'),
                                        'type': 'earnings'
                                    })
                                    found_earnings = True
                                    break  # Only show next upcoming earnings
                            except Exception as e:
                                import traceback
                                print(f"Error processing earnings date for {ticker}: {str(e)}")
                                traceback.print_exc()
                                continue
                        
                        # If no earnings found in the range, try to get next earnings anyway (even if further out)
                        if not found_earnings and len(earnings_dates) > 0:
                            try:
                                # Get the first (most recent future) earnings date
                                for date_idx in earnings_dates.index:
                                    try:
                                        earnings_date = pd.Timestamp(date_idx)
                                        if hasattr(earnings_date, 'date'):
                                            earnings_date = earnings_date.date()
                                        else:
                                            earnings_date = earnings_date.to_pydatetime().date()
                                        
                                        days_diff = (earnings_date - today).days
                                        # If it's in the future, show it
                                        if days_diff > 0:
                                            earnings_alerts.append({
                                                'ticker': ticker,
                                                'company_name': info.get('longName', ticker),
                                                'earnings_date': earnings_date.strftime('%Y-%m-%d'),
                                                'earnings_date_display': earnings_date.strftime('%B %d, %Y'),
                                                'days_until': days_diff,
                                                'priority': 'low',
                                                'type': 'earnings'
                                            })
                                            break
                                    except:
                                        continue
                            except Exception as e:
                                print(f"Error getting next earnings for {ticker}: {str(e)}")
                                pass
                except Exception as e:
                    print(f"Error fetching earnings_dates for {ticker}: {str(e)}")
                    pass
                
                # Get recent news with high sentiment
                try:
                    news = get_stock_news(ticker, max_news=5)
                    for article in news:
                        # Alert for high sentiment news (positive or negative)
                        sentiment_score = article.get('sentiment_score', 0)
                        if abs(sentiment_score) > 0.3:  # Strong sentiment
                            news_alerts.append({
                                'ticker': ticker,
                                'title': article.get('title', ''),
                                'summary': article.get('summary', '')[:200],
                                'link': article.get('link', ''),
                                'publisher': article.get('publisher', ''),
                                'published': article.get('published', ''),
                                'sentiment': article.get('sentiment', 'neutral'),
                                'sentiment_score': sentiment_score,
                                'priority': 'high' if abs(sentiment_score) > 0.5 else 'medium',
                                'type': 'news'
                            })
                except:
                    pass
                
                # Small delay to avoid rate limiting
                if (i + 1) % 3 == 0:
                    time.sleep(0.3)
                    
            except Exception as e:
                print(f"Error processing alerts for {ticker}: {str(e)}")
                continue
        
        # Sort earnings alerts by date
        earnings_alerts.sort(key=lambda x: x['earnings_date'])
        
        # Sort news alerts by sentiment score (absolute value)
        news_alerts.sort(key=lambda x: abs(x.get('sentiment_score', 0)), reverse=True)
        
        return jsonify({
            'earnings_alerts': clean_for_json(earnings_alerts),
            'news_alerts': clean_for_json(news_alerts[:20]),  # Limit to top 20 news
            'total': len(earnings_alerts) + len(news_alerts)
        })
        
    except Exception as e:
        print(f"Error in alerts dashboard: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': f'Failed to fetch alerts: {str(e)}',
            'earnings_alerts': [],
            'news_alerts': [],
            'total': 0
        }), 500

@app.route('/api/financials/<ticker>')
def get_financials(ticker):
    """Get comprehensive financial data for Financials tab"""
    try:
        financials = get_financials_data(ticker.upper())
        
        if financials is None:
            return jsonify({'error': 'Financial data not available'}), 404
        
        return jsonify(clean_for_json(financials))
        
    except Exception as e:
        print(f"Error in financials endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to fetch financials: {str(e)}'}), 500

def get_finviz_analyst_ratings(ticker):
    """Scrape individual analyst ratings from Finviz"""
    try:
        url = f"https://finviz.com/quote.ashx?t={ticker.upper()}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"Finviz returned status {response.status_code} for {ticker}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        recommendations = []
        
        # Finviz has analyst ratings in a table with header: date, action, analyst, rating change, price target change
        all_tables = soup.find_all('table')
        
        for table in all_tables:
            rows = table.find_all('tr')
            if len(rows) > 1:
                header_row = rows[0]
                header_cells = header_row.find_all(['td', 'th'])
                header_texts = [cell.get_text(strip=True).lower() for cell in header_cells]
                
                # Look for analyst table with: date, action, analyst, rating change, price target change
                # Must have both 'date' and 'analyst' in header, and 'action' or 'rating'
                # Also check that it has exactly 5 columns (date, action, analyst, rating change, price target change)
                if 'date' in header_texts and 'analyst' in header_texts and ('action' in header_texts or 'rating' in header_texts) and len(header_cells) == 5:
                    # Verify this is the right table by checking first data row
                    if len(rows) > 1:
                        first_data_row = rows[1]
                        first_data_cells = first_data_row.find_all(['td', 'th'])
                        if len(first_data_cells) == 5:
                            first_row_text = ' '.join([cell.get_text(strip=True).lower() for cell in first_data_cells])
                            # First row should contain action words like "upgrade", "downgrade", "initiate", etc.
                            if any(word in first_row_text for word in ['upgrade', 'downgrade', 'initiate', 'maintain', 'reiterate', 'perform', 'outperform', 'underperform']):
                                # Found analyst table - Finviz format: Date, Action, Analyst, Rating Change, Price Target Change
                                for row in rows[1:31]:  # Skip header, limit to 30
                                    try:
                                        cells = row.find_all(['td', 'th'])
                                        if len(cells) < 3:
                                            continue
                                        
                                        # Finviz format based on test:
                                        # cells[0] = Date (e.g., "Nov-14-25")
                                        # cells[1] = Action (e.g., "Upgrade")
                                        # cells[2] = Analyst (e.g., "Oppenheimer")
                                        # cells[3] = Rating Change (e.g., "Perform → Outperform")
                                        # cells[4] = Price Target Change (if exists)
                                        
                                        date_str = cells[0].get_text(strip=True) if len(cells) > 0 else 'N/A'
                                        action = cells[1].get_text(strip=True) if len(cells) > 1 else 'N/A'
                                        firm = cells[2].get_text(strip=True) if len(cells) > 2 else 'N/A'
                                        rating_change = cells[3].get_text(strip=True) if len(cells) > 3 else 'N/A'
                                        target_change = cells[4].get_text(strip=True) if len(cells) > 4 else ''
                                        
                                        # Extract "to" rating from rating change (e.g., "Perform → Outperform" -> "Outperform")
                                        rating = 'N/A'
                                        if '→' in rating_change:
                                            parts = rating_change.split('→')
                                            if len(parts) > 1:
                                                rating = parts[1].strip()
                                        elif rating_change and rating_change != 'N/A':
                                            rating = rating_change
                                        
                                        # Extract target price from target change if available
                                        target_price = None
                                        if target_change and '$' in target_change:
                                            try:
                                                # Extract number after $
                                                import re
                                                match = re.search(r'\$(\d+\.?\d*)', target_change)
                                                if match:
                                                    target_price = float(match.group(1))
                                            except:
                                                pass
                                        
                                        # Only add if we have firm and rating
                                        if firm != 'N/A' and firm and rating != 'N/A' and rating:
                                            recommendations.append({
                                                'date': date_str,
                                                'firm': firm,
                                                'to_grade': rating,
                                                'from_grade': rating_change.split('→')[0].strip() if '→' in rating_change else 'N/A',
                                                'target_price': target_price
                                            })
                                    except Exception as e:
                                        print(f"Error parsing Finviz analyst row: {str(e)}")
                                        import traceback
                                        traceback.print_exc()
                                        continue
                                
                                if recommendations:
                                    break
        
        return recommendations if recommendations else None
        
    except Exception as e:
        print(f"Error scraping Finviz analyst ratings for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def get_benzinga_analyst_ratings(ticker):
    """Scrape individual analyst ratings from Benzinga"""
    try:
        url = f"https://www.benzinga.com/quote/{ticker.upper()}/ratings"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        recommendations = []
        
        # Benzinga uses various structures - look for analyst data
        # Try to find structured data (could be in tables, divs, or JSON)
        all_elements = soup.find_all(['table', 'div', 'section'])
        
        for element in all_elements:
            text = element.get_text().lower()
            if 'analyst' in text and ('rating' in text or 'target' in text):
                # Try to extract data from this element
                rows = element.find_all(['tr', 'div'], class_=lambda x: x and 'row' in str(x).lower() if x else False)
                if not rows:
                    rows = element.find_all('tr')
                
                for row in rows[1:31]:  # Skip header
                    try:
                        cells = row.find_all(['td', 'th', 'div'])
                        if len(cells) < 2:
                            continue
                        
                        firm = 'N/A'
                        rating = 'N/A'
                        target_price = None
                        date_str = 'N/A'
                        
                        for cell in cells:
                            text = cell.get_text(strip=True)
                            text_lower = text.lower()
                            
                            # Firm name
                            if len(text) > 3 and len(text) < 50 and not any(c in text for c in ['$', '/', '-']) and \
                               not text.replace(',', '').replace('.', '').isdigit():
                                if firm == 'N/A':
                                    firm = text
                            
                            # Rating
                            if any(word in text_lower for word in ['buy', 'sell', 'hold', 'outperform', 'underperform', 'neutral', 'strong']):
                                if rating == 'N/A':
                                    rating = text
                            
                            # Target price
                            if '$' in text:
                                try:
                                    clean_price = text.replace('$', '').replace(',', '').replace(' ', '')
                                    if clean_price:
                                        target_price = float(clean_price)
                                except:
                                    pass
                            
                            # Date
                            if any(x in text for x in ['2024', '2025', '2023']) or ('/' in text and len(text) < 15):
                                if date_str == 'N/A':
                                    date_str = text
                        
                        if firm != 'N/A' and rating != 'N/A':
                            recommendations.append({
                                'date': date_str,
                                'firm': firm,
                                'to_grade': rating,
                                'from_grade': 'N/A',
                                'target_price': target_price
                            })
                    except:
                        continue
                
                if recommendations:
                    break
        
        return recommendations if recommendations else None
        
    except Exception as e:
        print(f"Error scraping Benzinga for {ticker}: {str(e)}")
        return None

def get_marketbeat_analyst_ratings(ticker):
    """Scrape individual analyst ratings from MarketBeat"""
    try:
        urls = [
            f"https://www.marketbeat.com/stocks/NASDAQ/{ticker}/forecast/",
            f"https://www.marketbeat.com/stocks/NASDAQ/{ticker}/",
            f"https://www.marketbeat.com/stocks/NYSE/{ticker}/forecast/",
            f"https://www.marketbeat.com/stocks/NYSE/{ticker}/",
        ]
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        
        recommendations = []
        
        for url in urls:
            try:
                response = requests.get(url, headers=headers, timeout=15)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # Look for analyst ratings table
                    tables = soup.find_all('table')
                    ratings_table = None
                    
                    for table in tables:
                        rows = table.find_all('tr')
                        if len(rows) > 1:
                            header_text = rows[0].get_text().lower()
                            # Look for analyst ratings table
                            if ('analyst' in header_text or 'firm' in header_text or 'rating' in header_text) and \
                               ('target' in header_text or 'price' in header_text):
                                ratings_table = table
                                break
                    
                    # Also try div-based structure
                    if not ratings_table:
                        divs = soup.find_all('div', class_=lambda x: x and ('analyst' in str(x).lower() or 'rating' in str(x).lower() or 'recommendation' in str(x).lower()) if x else False)
                        for div in divs:
                            # Look for structured data in divs
                            rows = div.find_all(['tr', 'div'], class_=lambda x: x and 'row' in str(x).lower() if x else False)
                            if len(rows) > 1:
                                ratings_table = div
                                break
                    
                    if ratings_table:
                        rows = ratings_table.find_all(['tr', 'div'])
                        for row in rows[1:31]:  # Skip header, limit to 30
                            try:
                                cells = row.find_all(['td', 'th', 'div'])
                                if len(cells) < 3:
                                    continue
                                
                                # Try to extract: Firm, Date, Rating, Target Price
                                firm = 'N/A'
                                date_str = 'N/A'
                                rating = 'N/A'
                                target_price = None
                                
                                for i, cell in enumerate(cells):
                                    text = cell.get_text(strip=True)
                                    text_lower = text.lower()
                                    
                                    # Firm name (usually longer text, not a number, not a date)
                                    if len(text) > 3 and not any(c in text for c in ['$', '/', '-']) and \
                                       not text.replace(',', '').replace('.', '').isdigit() and \
                                       not any(x in text for x in ['2024', '2025', '2023']) and \
                                       'buy' not in text_lower and 'sell' not in text_lower and 'hold' not in text_lower:
                                        if firm == 'N/A' and len(text) < 50:  # Reasonable firm name length
                                            firm = text
                                    
                                    # Rating (Buy, Hold, Sell, Strong Buy, etc.)
                                    if any(word in text_lower for word in ['buy', 'sell', 'hold', 'outperform', 'underperform', 'neutral']):
                                        if rating == 'N/A':
                                            rating = text
                                    
                                    # Target price (contains $ or numbers)
                                    if '$' in text:
                                        try:
                                            clean_price = text.replace('$', '').replace(',', '').replace(' ', '')
                                            if clean_price:
                                                target_price = float(clean_price)
                                        except:
                                            pass
                                    
                                    # Date
                                    if any(x in text for x in ['2024', '2025', '2023']) or \
                                       ('/' in text and len(text) < 15) or \
                                       ('-' in text and len(text) < 15):
                                        if date_str == 'N/A':
                                            date_str = text
                                
                                # Only add if we have firm and rating
                                if firm != 'N/A' and rating != 'N/A':
                                    recommendations.append({
                                        'date': date_str,
                                        'firm': firm,
                                        'to_grade': rating,
                                        'from_grade': 'N/A',
                                        'target_price': target_price
                                    })
                            except Exception as e:
                                print(f"Error parsing MarketBeat rating row: {str(e)}")
                                continue
                        
                        if recommendations:
                            break  # Found data, no need to try other URLs
            except Exception as e:
                print(f"Error accessing {url}: {str(e)}")
                continue
        
        return recommendations if recommendations else None
        
    except Exception as e:
        print(f"Error scraping MarketBeat analyst ratings for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

@app.route('/api/analyst-data/<ticker>')
def get_analyst_data(ticker):
    """Get analyst ratings and price targets"""
    try:
        stock = yf.Ticker(ticker.upper())
        time.sleep(0.3)  # Rate limiting
        
        # Get info (don't fail if incomplete)
        try:
            info = stock.info
            if not info:
                info = {}
        except:
            info = {}
        
        # Get individual recommendations from Finviz (works better than MarketBeat/Benzinga)
        recommendations = []
        try:
            print(f"[ANALYST] Trying to get recommendations for {ticker.upper()}")
            # Try Finviz first (most reliable)
            fv_recs = get_finviz_analyst_ratings(ticker.upper())
            if fv_recs and len(fv_recs) > 0:
                recommendations = fv_recs
                print(f"[ANALYST] Found {len(recommendations)} recommendations from Finviz for {ticker}")
            else:
                print(f"[ANALYST] No Finviz recommendations for {ticker}, trying MarketBeat")
                # Try MarketBeat as fallback
                mb_recs = get_marketbeat_analyst_ratings(ticker.upper())
                if mb_recs and len(mb_recs) > 0:
                    recommendations = mb_recs
                    print(f"[ANALYST] Found {len(recommendations)} recommendations from MarketBeat for {ticker}")
                else:
                    print(f"[ANALYST] No MarketBeat recommendations for {ticker}, trying Benzinga")
                    # Try Benzinga as last fallback
                    bz_recs = get_benzinga_analyst_ratings(ticker.upper())
                    if bz_recs and len(bz_recs) > 0:
                        recommendations = bz_recs
                        print(f"[ANALYST] Found {len(recommendations)} recommendations from Benzinga for {ticker}")
                    else:
                        print(f"[ANALYST] No recommendations found from any source for {ticker}")
        except Exception as e:
            print(f"[ANALYST] Error getting recommendations: {str(e)}")
            import traceback
            traceback.print_exc()
            recommendations = []
        
        # Get recommendation summary
        recommendation_summary = None
        try:
            rec_summary = stock.recommendations_summary
            if rec_summary is not None and not rec_summary.empty:
                latest = rec_summary.iloc[-1] if len(rec_summary) > 0 else None
                if latest is not None:
                    recommendation_summary = {
                        'strong_buy': int(latest.get('strongBuy', 0)) if pd.notna(latest.get('strongBuy', 0)) else 0,
                        'buy': int(latest.get('buy', 0)) if pd.notna(latest.get('buy', 0)) else 0,
                        'hold': int(latest.get('hold', 0)) if pd.notna(latest.get('hold', 0)) else 0,
                        'sell': int(latest.get('sell', 0)) if pd.notna(latest.get('sell', 0)) else 0,
                        'strong_sell': int(latest.get('strongSell', 0)) if pd.notna(latest.get('strongSell', 0)) else 0
                    }
        except:
            pass
        
        # Get price targets
        target_mean_price = info.get('targetMeanPrice')
        target_high_price = info.get('targetHighPrice')
        target_low_price = info.get('targetLowPrice')
        current_price = info.get('currentPrice') or info.get('regularMarketPrice')
        
        # Calculate upside/downside
        upside_pct = None
        if target_mean_price and current_price:
            upside_pct = ((target_mean_price - current_price) / current_price) * 100
        
        # Also add individual price targets from recommendations if available
        individual_targets = []
        if recommendations:
            for rec in recommendations:
                if rec.get('target_price'):
                    individual_targets.append({
                        'firm': rec.get('firm', 'N/A'),
                        'target_price': rec.get('target_price'),
                        'rating': rec.get('to_grade', 'N/A'),
                        'date': rec.get('date', 'N/A')
                    })
        
        analyst_data = {
            'recommendations': recommendations[:20] if recommendations else [],  # Last 20
            'recommendation_summary': recommendation_summary,
            'target_mean_price': target_mean_price,
            'target_high_price': target_high_price,
            'target_low_price': target_low_price,
            'current_price': current_price,
            'upside_pct': upside_pct,
            'number_of_analysts': info.get('numberOfAnalystOpinions'),
            'individual_targets': individual_targets[:10] if individual_targets else []
        }
        
        return jsonify(clean_for_json(analyst_data))
        
    except Exception as e:
        print(f"Error fetching analyst data for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to fetch analyst data: {str(e)}'}), 500

def get_marketbeat_insider_trading(ticker):
    """Scrape insider trading data from MarketBeat"""
    try:
        # MarketBeat uses different URL format - try multiple variations
        urls = [
            f"https://www.marketbeat.com/stocks/NASDAQ/{ticker.upper()}/insider-trades/",
            f"https://www.marketbeat.com/stocks/NASDAQ/{ticker.upper()}/insiders/",
            f"https://www.marketbeat.com/stocks/NYSE/{ticker.upper()}/insider-trades/",
            f"https://www.marketbeat.com/stocks/NYSE/{ticker.upper()}/insiders/",
            f"https://www.marketbeat.com/stocks/{ticker.upper()}/insider-trades/"
        ]
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://www.google.com/',
        }
        
        transactions = []
        
        for url in urls:
            try:
                response = requests.get(url, headers=headers, timeout=15)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # Look for insider trading table
                    tables = soup.find_all('table')
                    insider_table = None
                    
                    for table in tables:
                        rows = table.find_all('tr')
                        if len(rows) > 1:
                            header_text = rows[0].get_text().lower()
                            # MarketBeat typically has headers like "Date", "Insider", "Transaction", "Shares", "Value"
                            if ('insider' in header_text or 'transaction' in header_text) and \
                               ('date' in header_text or 'shares' in header_text):
                                insider_table = table
                                break
                    
                    if insider_table:
                        rows = insider_table.find_all('tr')
                        for row in rows[1:31]:  # Skip header, limit to 30
                            try:
                                cells = row.find_all(['td', 'th'])
                                if len(cells) < 4:
                                    continue
                                
                                # MarketBeat format varies, try to extract common fields
                                # Typical: Date, Insider, Position, Transaction Type, Shares, Value
                                date_str = 'N/A'
                                insider = 'N/A'
                                position = 'N/A'
                                transaction_type = None
                                shares = None
                                value = None
                                
                                # Try to parse cells - MarketBeat structure may vary
                                for i, cell in enumerate(cells):
                                    text = cell.get_text(strip=True)
                                    text_lower = text.lower()
                                    
                                    # Date detection
                                    if any(x in text for x in ['2024', '2025', '2023']) or \
                                       ('/' in text and len(text) < 15) or \
                                       ('-' in text and len(text) < 15):
                                        date_str = text
                                    
                                    # Transaction type
                                    if 'sale' in text_lower or 'sell' in text_lower:
                                        transaction_type = 'sell'
                                    elif ('purchase' in text_lower or 'buy' in text_lower or 'acquisition' in text_lower or
                                          'option exercise' in text_lower or 'exercise' in text_lower or
                                          'grant' in text_lower or 'award' in text_lower or
                                          'conversion' in text_lower or 'convert' in text_lower):
                                        transaction_type = 'buy'
                                    
                                    # Value (contains $ or large numbers with commas)
                                    if '$' in text or (',' in text and len(text) > 5 and any(c.isdigit() for c in text)):
                                        try:
                                            clean_value = text.replace('$', '').replace(',', '').replace(' ', '')
                                            if clean_value and clean_value.replace('.', '').isdigit():
                                                value = float(clean_value)
                                        except:
                                            pass
                                    
                                    # Shares (numbers, possibly with K/M suffixes)
                                    if not '$' in text and any(c.isdigit() for c in text):
                                        try:
                                            clean_shares = text.replace(',', '').replace(' ', '').upper()
                                            if 'K' in clean_shares:
                                                shares = int(float(clean_shares.replace('K', '')) * 1000)
                                            elif 'M' in clean_shares:
                                                shares = int(float(clean_shares.replace('M', '')) * 1000000)
                                            else:
                                                if clean_shares.replace('.', '').isdigit():
                                                    shares = int(float(clean_shares))
                                        except:
                                            pass
                                    
                                    # Insider name (longer text, not a number, not a date)
                                    if len(text) > 5 and not any(c in text for c in ['$', '/', '-']) and \
                                       not text.replace(',', '').replace('.', '').isdigit() and \
                                       not any(x in text for x in ['2024', '2025', '2023']):
                                        if insider == 'N/A':
                                            insider = text
                                
                                if transaction_type and value and value > 0:
                                    transactions.append({
                                        'date': date_str,
                                        'transaction_type': transaction_type,
                                        'value': value,
                                        'shares': shares,
                                        'insider': insider,
                                        'position': position,
                                        'text': transaction_type
                                    })
                            except Exception as e:
                                print(f"Error parsing MarketBeat row: {str(e)}")
                                continue
                        
                        if transactions:
                            break  # Found data, no need to try other URLs
            except Exception as e:
                print(f"Error accessing {url}: {str(e)}")
                continue
        
        return transactions if transactions else None
        
    except Exception as e:
        print(f"Error scraping MarketBeat for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def get_finviz_insider_trading(ticker):
    """Scrape insider trading data from Finviz"""
    try:
        url = f"https://finviz.com/quote.ashx?t={ticker.upper()}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://www.google.com/',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"Finviz returned status {response.status_code} for {ticker}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        transactions = []
        
        # Finviz has insider trading in a table
        # Look for table with "Insider Trading" header
        all_tables = soup.find_all('table')
        insider_table = None
        
        for i, table in enumerate(all_tables):
            rows = table.find_all('tr')
            if len(rows) > 1:
                header_row = rows[0]
                header_cells = header_row.find_all(['td', 'th'])
                header_text = header_row.get_text().lower()
                
                # Look for insider trading table with proper structure
                # Must have: "Insider Trading", "Relationship", "Date", "Transaction"
                # And should have around 8-9 columns
                if 'insider trading' in header_text and 'relationship' in header_text and 'date' in header_text and 'transaction' in header_text:
                    if 7 <= len(header_cells) <= 10:  # Should have 8-9 columns
                        insider_table = table
                        break
        
        if insider_table:
            rows = insider_table.find_all('tr')
            for row_idx, row in enumerate(rows[1:31]):  # Skip header, limit to 30
                try:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) < 6:
                        continue
                    
                    # Finviz actual format from debug:
                    # cells[0] = Insider name (e.g., "KONDO CHRIS")
                    # cells[1] = Position (e.g., "Principal Accounting Officer")
                    # cells[2] = Date (e.g., "Nov 07 '25")
                    # cells[3] = Transaction type (e.g., "Sale", "Proposed Sale")
                    # cells[4] = Cost per share (e.g., "271.23")
                    # cells[5] = Number of shares (e.g., "3,752")
                    # cells[6] = Total value (if exists)
                    
                    insider_name = cells[0].get_text(strip=True) if len(cells) > 0 else 'N/A'
                    position = cells[1].get_text(strip=True) if len(cells) > 1 else 'N/A'
                    date_str = cells[2].get_text(strip=True) if len(cells) > 2 else 'N/A'
                    transaction_text = cells[3].get_text(strip=True) if len(cells) > 3 else ''
                    cost_per_share_text = cells[4].get_text(strip=True) if len(cells) > 4 else ''
                    shares_text = cells[5].get_text(strip=True) if len(cells) > 5 else ''
                    value_text = cells[6].get_text(strip=True) if len(cells) > 6 else ''
                    
                    # Determine transaction type
                    transaction_type = None
                    trans_lower = transaction_text.lower()
                    if 'sale' in trans_lower or 'sell' in trans_lower:
                        transaction_type = 'sell'
                    elif ('purchase' in trans_lower or 'buy' in trans_lower or 'acquisition' in trans_lower or 
                          'option exercise' in trans_lower or 'exercise' in trans_lower or
                          'grant' in trans_lower or 'award' in trans_lower or
                          'conversion' in trans_lower or 'convert' in trans_lower):
                        transaction_type = 'buy'
                    
                    # Parse shares (from cells[5])
                    shares = None
                    if shares_text:
                        try:
                            clean_shares = shares_text.replace(',', '').replace(' ', '')
                            if clean_shares:
                                shares = int(float(clean_shares))
                        except:
                            pass
                    
                    # Parse value - try cells[6] first, otherwise calculate from cost_per_share * shares
                    value = None
                    if value_text:
                        try:
                            clean_value = value_text.replace('$', '').replace(',', '').replace(' ', '')
                            if clean_value:
                                value = float(clean_value)
                        except:
                            pass
                    
                    # If no value in cells[6], calculate from cost_per_share * shares
                    if value is None and cost_per_share_text and shares:
                        try:
                            cost_per_share = float(cost_per_share_text.replace(',', '').replace(' ', ''))
                            value = cost_per_share * shares
                        except:
                            pass
                    
                    if transaction_type and value and value > 0:
                        print(f"DEBUG Finviz: Adding {transaction_type} transaction: {insider_name}, value={value}, shares={shares}, text={transaction_text}")
                        transactions.append({
                            'date': date_str,
                            'transaction_type': transaction_type,
                            'value': value,
                            'shares': shares,
                            'insider': insider_name,
                            'position': position,
                            'text': transaction_text
                        })
                    else:
                        if transaction_type:
                            print(f"DEBUG Finviz: Skipping {transaction_type} row {row_idx+1} - value={value}, shares={shares}, text={transaction_text}")
                        else:
                            print(f"DEBUG Finviz: Skipping row {row_idx+1} - no transaction type detected, text={transaction_text}")
                except Exception as e:
                    print(f"Error parsing Finviz row: {str(e)}")
                    continue
        
        return transactions if transactions else None
        
    except Exception as e:
        print(f"Error scraping Finviz for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def get_tipranks_insider_trading(ticker):
    """Scrape insider trading data from TipRanks"""
    try:
        url = f"https://www.tipranks.com/stocks/{ticker.upper()}/insider-trading"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"TipRanks returned status {response.status_code} for {ticker}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        transactions = []
        
        # TipRanks uses tables or divs with specific classes for insider transactions
        # Look for transaction rows
        transaction_rows = soup.find_all('tr', class_=lambda x: x and ('transaction' in str(x).lower() or 'insider' in str(x).lower()))
        
        # If no specific class, try to find table rows
        if not transaction_rows:
            tables = soup.find_all('table')
            for table in tables:
                rows = table.find_all('tr')
                if len(rows) > 1:  # Has header + data rows
                    transaction_rows = rows[1:]  # Skip header
                    break
        
        # Alternative: look for div-based structure
        if not transaction_rows:
            transaction_divs = soup.find_all('div', class_=lambda x: x and ('transaction' in str(x).lower() or 'insider' in str(x).lower() or 'row' in str(x).lower()))
            if transaction_divs:
                transaction_rows = transaction_divs
        
        for row in transaction_rows[:30]:  # Limit to 30 most recent
            try:
                # Extract data from row
                cells = row.find_all(['td', 'th', 'div'])
                if len(cells) < 3:
                    continue
                
                # Try to extract: Date, Insider, Position, Transaction Type, Shares, Value
                date_str = 'N/A'
                insider = 'N/A'
                position = 'N/A'
                transaction_type = None
                shares = None
                value = None
                
                # Parse cells - TipRanks structure may vary
                for i, cell in enumerate(cells):
                    text = cell.get_text(strip=True)
                    text_lower = text.lower()
                    
                    # Date detection
                    if any(x in text for x in ['2024', '2025', '2023']) or '/' in text or '-' in text:
                        if len(text) < 20:  # Likely a date
                            date_str = text
                    
                    # Transaction type detection
                    if 'sale' in text_lower or 'sell' in text_lower:
                        transaction_type = 'sell'
                    elif 'purchase' in text_lower or 'buy' in text_lower or 'acquisition' in text_lower:
                        transaction_type = 'buy'
                    
                    # Value detection (contains $ or numbers with commas)
                    if '$' in text or (',' in text and any(c.isdigit() for c in text)):
                        try:
                            # Remove $ and commas, convert to float
                            clean_text = text.replace('$', '').replace(',', '').replace(' ', '')
                            if clean_text:
                                value = float(clean_text)
                        except:
                            pass
                    
                    # Shares detection (numbers without $)
                    if not '$' in text and any(c.isdigit() for c in text) and (',' in text or int(text.replace(',', '').replace(' ', '')) > 0):
                        try:
                            clean_text = text.replace(',', '').replace(' ', '')
                            if clean_text.isdigit():
                                shares = int(clean_text)
                        except:
                            pass
                    
                    # Insider name (usually longer text, not a number)
                    if len(text) > 5 and not any(c in text for c in ['$', '/', '-']) and not text.replace(',', '').replace('.', '').isdigit():
                        if insider == 'N/A' and 'insider' not in text_lower:
                            insider = text
                
                # Only add if we have valid transaction type and value
                if transaction_type and value and value > 0:
                    transactions.append({
                        'date': date_str,
                        'transaction_type': transaction_type,
                        'value': value,
                        'shares': shares,
                        'insider': insider,
                        'position': position
                    })
            except Exception as e:
                print(f"Error parsing TipRanks row: {str(e)}")
                continue
        
        return transactions if transactions else None
        
    except Exception as e:
        print(f"Error scraping TipRanks for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def get_sec_api_insider_trading(ticker):
    """Get insider trading data from SEC API (sec-api.io) - official SEC Form 3, 4, 5 filings"""
    if not SEC_API_KEY:
        print("SEC_API_KEY not configured, skipping SEC API")
        return None
    
    try:
        # SEC API endpoint for Form 4 (most common insider trading form)
        url = "https://api.sec-api.io/form-4"
        
        headers = {
            'Authorization': SEC_API_KEY,
            'Content-Type': 'application/json'
        }
        
        # Query for searching by ticker symbol
        # SEC API uses Elasticsearch query format
        query = {
            "query": {
                "query_string": {
                    "query": f"issuer.tradingSymbol:{ticker.upper()}"
                }
            },
            "from": 0,
            "size": 30,
            "sort": [{"filedAt": {"order": "desc"}}]
        }
        
        response = requests.post(url, headers=headers, json=query, timeout=15)
        
        if response.status_code == 200:
            data = response.json()
            transactions = []
            
            filings = data.get('filings', [])
            if not filings:
                print(f"SEC API returned no filings for {ticker}")
                return None
            
            for filing in filings:
                try:
                    # Get filing date
                    filed_at = filing.get('filedAt', '')
                    date_str = filed_at[:10] if filed_at else 'N/A'  # Extract YYYY-MM-DD
                    
                    # Get reporting owner (insider) info
                    reporting_owner = filing.get('reportingOwner', {})
                    insider_name = reporting_owner.get('name', 'N/A')
                    
                    # Get relationship
                    relationship = reporting_owner.get('relationship', {})
                    position = 'N/A'
                    if relationship.get('isOfficer', False):
                        position = 'Officer'
                    elif relationship.get('isDirector', False):
                        position = 'Director'
                    elif relationship.get('isTenPercentOwner', False):
                        position = '10% Owner'
                    elif relationship.get('isOther', False):
                        position = 'Other'
                    
                    # Process non-derivative transactions (direct stock purchases/sales)
                    non_derivative = filing.get('nonDerivativeTable', {}).get('holdings', [])
                    for holding in non_derivative:
                        transactions_list = holding.get('transactions', [])
                        for trans in transactions_list:
                            transaction_code = trans.get('transactionCode', '')
                            shares = trans.get('shares', 0)
                            price = trans.get('pricePerShare', 0)
                            
                            # Calculate value
                            value = 0
                            if shares and price:
                                try:
                                    value = float(shares) * float(price)
                                except:
                                    pass
                            
                            # Determine transaction type based on SEC transaction codes
                            # P = Open market purchase, A = Grant/award, I = Discretionary transaction (acquisition)
                            # S = Open market sale, D = Disposition to issuer, F = Payment of exercise price
                            transaction_type = None
                            if transaction_code in ['P', 'A', 'I', 'M', 'X', 'C', 'L']:  # Purchase codes
                                transaction_type = 'buy'
                            elif transaction_code in ['S', 'D', 'F', 'E', 'H', 'U']:  # Sale codes
                                transaction_type = 'sell'
                            
                            if transaction_type and value > 0:
                                print(f"DEBUG SEC API: Adding {transaction_type} transaction: {insider_name}, value={value}, shares={shares}, code={transaction_code}")
                                transactions.append({
                                    'date': date_str,
                                    'transaction_type': transaction_type,
                                    'value': value,
                                    'shares': int(shares) if shares else 0,
                                    'insider': insider_name,
                                    'position': position,
                                    'transaction_code': transaction_code
                                })
                            elif transaction_type:
                                print(f"DEBUG SEC API: Skipping {transaction_type} transaction (value={value}, shares={shares}, code={transaction_code})")
                    
                    # Process derivative transactions (options, warrants, etc.)
                    derivative = filing.get('derivativeTable', {}).get('holdings', [])
                    for holding in derivative:
                        transactions_list = holding.get('transactions', [])
                        for trans in transactions_list:
                            transaction_code = trans.get('transactionCode', '')
                            shares = trans.get('shares', 0)
                            price = trans.get('pricePerShare', 0)
                            
                            value = 0
                            if shares and price:
                                try:
                                    value = float(shares) * float(price)
                                except:
                                    pass
                            
                            transaction_type = None
                            if transaction_code in ['P', 'A', 'I', 'M', 'X', 'C']:
                                transaction_type = 'buy'
                            elif transaction_code in ['S', 'D', 'F', 'E', 'H']:
                                transaction_type = 'sell'
                            
                            if transaction_type and value > 0:
                                transactions.append({
                                    'date': date_str,
                                    'transaction_type': transaction_type,
                                    'value': value,
                                    'shares': int(shares) if shares else 0,
                                    'insider': insider_name,
                                    'position': f'Derivative ({position})',
                                    'transaction_code': transaction_code
                                })
                
                except Exception as filing_error:
                    print(f"Error processing SEC filing: {str(filing_error)}")
                    continue
            
            return transactions if transactions else None
            
        elif response.status_code == 401:
            print(f"SEC API authentication failed - check API key")
            return None
        elif response.status_code == 429:
            print(f"SEC API rate limit exceeded")
            return None
        else:
            print(f"SEC API returned status {response.status_code}: {response.text[:200]}")
            return None
            
    except Exception as e:
        print(f"Error fetching SEC API insider trading for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

@app.route('/api/insider-trading/<ticker>')
def get_insider_trading(ticker):
    """Get insider trading activity from SEC API (primary), Finviz/MarketBeat (fallback), yfinance (last resort)"""
    try:
        ticker_upper = ticker.upper()
        time.sleep(0.3)  # Rate limiting
        
        insider_transactions = []
        
        # Try SEC API first (most reliable and official source)
        sec_data = get_sec_api_insider_trading(ticker_upper)
        if sec_data and len(sec_data) > 0:
            print(f"SEC API returned {len(sec_data)} transactions for {ticker_upper}")
            insider_transactions = sec_data
        else:
            # Fallback to Finviz
            print(f"SEC API returned no data for {ticker_upper}, trying Finviz")
            finviz_data = get_finviz_insider_trading(ticker_upper)
            if finviz_data and len(finviz_data) > 0:
                print(f"Finviz returned {len(finviz_data)} transactions for {ticker_upper}")
                insider_transactions = finviz_data
            else:
                # Fallback to MarketBeat
                print(f"Finviz returned no data for {ticker_upper}, trying MarketBeat")
                marketbeat_data = get_marketbeat_insider_trading(ticker_upper)
                if marketbeat_data and len(marketbeat_data) > 0:
                    print(f"MarketBeat returned {len(marketbeat_data)} transactions for {ticker_upper}")
                    insider_transactions = marketbeat_data
                else:
                    # Last resort: yfinance
                    print(f"MarketBeat returned no data for {ticker_upper}, trying yfinance fallback")
                    try:
                        stock = yf.Ticker(ticker_upper)
                        insider_df = stock.insider_transactions
                        if insider_df is not None and not insider_df.empty:
                            for idx, row in insider_df.tail(30).iterrows():
                                try:
                                    row_dict = row.to_dict()
                                    
                                    transaction_type = None
                                    text = str(row_dict.get('Text', '')).lower() if row_dict.get('Text') else ''
                                    
                                    if 'sale' in text or 'sell' in text:
                                        transaction_type = 'sell'
                                    elif ('purchase' in text or 'buy' in text or 'acquisition' in text or
                                          'option exercise' in text.lower() or 'exercise' in text.lower() or
                                          'grant' in text.lower() or 'award' in text.lower() or
                                          'conversion' in text.lower() or 'convert' in text.lower()):
                                        transaction_type = 'buy'
                                    
                                    value = None
                                    val = row_dict.get('Value')
                                    if val is not None and pd.notna(val):
                                        try:
                                            value = float(val)
                                        except:
                                            pass
                                    
                                    shares = None
                                    sh = row_dict.get('Shares')
                                    if sh is not None and pd.notna(sh):
                                        try:
                                            shares = int(sh)
                                        except:
                                            pass
                                    
                                    insider = 'N/A'
                                    ins = row_dict.get('Insider')
                                    if ins is not None and pd.notna(ins):
                                        insider = str(ins)
                                    
                                    date_str = 'N/A'
                                    date_val = row_dict.get('Start Date')
                                    if date_val is not None and pd.notna(date_val):
                                        if hasattr(date_val, 'strftime'):
                                            date_str = date_val.strftime('%Y-%m-%d')
                                        else:
                                            date_str = str(date_val)
                                    elif hasattr(idx, 'strftime'):
                                        date_str = idx.strftime('%Y-%m-%d')
                                    
                                    if transaction_type and value is not None and value > 0:
                                        insider_transactions.append({
                                            'date': date_str,
                                            'transaction_type': transaction_type,
                                            'value': float(value),
                                            'shares': shares,
                                            'insider': insider,
                                            'text': str(row_dict.get('Text', 'N/A'))
                                        })
                                except Exception as row_error:
                                    continue
                    except Exception as yf_error:
                        print(f"yfinance fallback failed: {str(yf_error)}")
                        pass
        
        # Calculate totals from transactions
        total_purchases = 0
        total_sales = 0
        
        if insider_transactions:
            for trans in insider_transactions:
                if trans.get('transaction_type') == 'buy':
                    total_purchases += trans.get('value', 0)
                elif trans.get('transaction_type') == 'sell':
                    total_sales += trans.get('value', 0)
        
        # Separate transactions into purchases and sales
        purchases_from_transactions = [t for t in insider_transactions if t.get('transaction_type') == 'buy'][:10]
        sales_from_transactions = [t for t in insider_transactions if t.get('transaction_type') == 'sell'][:10]
        
        insider_data = {
            'transactions': insider_transactions[:20] if insider_transactions else [],
            'purchases': purchases_from_transactions,
            'sales': sales_from_transactions,
            'total_purchases': total_purchases,
            'total_sales': total_sales,
            'net_activity': total_purchases - total_sales
        }
        
        return jsonify(clean_for_json(insider_data))
        
    except Exception as e:
        print(f"Error fetching insider trading for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to fetch insider trading: {str(e)}'}), 500

if __name__ == '__main__':
    # Run without reloader to avoid cache issues
    import os
    os.environ['FLASK_ENV'] = 'production'
    app.run(debug=False, host='127.0.0.1', port=5001, use_reloader=False, threaded=True)

